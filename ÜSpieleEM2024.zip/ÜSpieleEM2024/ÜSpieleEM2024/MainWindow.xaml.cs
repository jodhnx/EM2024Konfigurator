﻿using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ÜSpieleEM2024
{
    
    public partial class MainWindow : Window
    {
        string[] GruppeANamen, GruppeBNamen, GruppeCNamen, GruppeDNamen, GruppeENamen, GruppeFNamen;
        int[] GruppeAPunkte, GruppeBPunkte, GruppeCPunkte, GruppeDPunkte, GruppeEPunkte, GruppeFPunkte;
        int[] GruppeAToreGeschossen, GruppeBToreGeschossen, GruppeCToreGeschossen, GruppeDToreGeschossen, GruppeEToreGeschossen, GruppeFToreGeschossen;
        string[] KOSpieleLand1, KOSpieleLand2, KOSpieleDatum;
        int[] GruppeAToreErhalten, GruppeBToreErhalten, GruppeCToreErhalten, GruppeDToreErhalten, GruppeEToreErhalten, GruppeFToreErhalten;
        int[] GruppeASiege, GruppeBSiege, GruppeCSiege, GruppeDSiege, GruppeESiege, GruppeFSiege;
        int[] GruppeANiederlagen, GruppeBNiederlagen, GruppeCNiederlagen, GruppeDNiederlagen, GruppeENiederlagen, GruppeFNiederlagen;
        int[] GruppeAUnentschieden, GruppeBUnentschieden, GruppeCUnentschieden, GruppeDUnentschieden, GruppeEUnentschieden, GruppeFUnentschieden;
        string[] SpieleGruppen, SpieleDatum;
        int[] SpieleLand1, SpieleLand2;
        string Sieger;
        int MomentanesSpiel, KOMomentanesSpiel;

        private void btKOSpeichern_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Tore1 = Convert.ToInt32(tbKOLand1.Text);
                int Tore2 = Convert.ToInt32(tbKOLand2.Text);
                if (Tore1 == Tore2)
                {
                    MessageBox.Show("Bitte geben sie gültige Werte für die Tore ein!");
                    UpdateKOEingabe();
                }
                else
                {
                    string momentanerSieger;
                    if (Tore1 > Tore2) momentanerSieger = KOSpieleLand1[KOMomentanesSpiel];
                    else momentanerSieger = KOSpieleLand2[KOMomentanesSpiel];
                    switch (KOMomentanesSpiel)
                    {
                        case 0:
                            KOSpieleLand1[8] = momentanerSieger;
                            break;
                        case 1:
                            KOSpieleLand2[8] = momentanerSieger;
                            break;
                        case 2:
                            KOSpieleLand1[9] = momentanerSieger;
                            break;
                        case 3:
                            KOSpieleLand2[9] = momentanerSieger;
                            break;
                        case 4:
                            KOSpieleLand1[10] = momentanerSieger;
                            break;
                        case 5:
                            KOSpieleLand2[10] = momentanerSieger;
                            break;
                        case 6:
                            KOSpieleLand1[11] = momentanerSieger;
                            break;
                        case 7:
                            KOSpieleLand2[11] = momentanerSieger;
                            break;
                        case 8:
                            KOSpieleLand1[12] = momentanerSieger;
                            break;
                        case 9:
                            KOSpieleLand2[12] = momentanerSieger;
                            break;
                        case 10:
                            KOSpieleLand1[13] = momentanerSieger;
                            break;
                        case 11:
                            KOSpieleLand2[13] = momentanerSieger;
                            break;
                        case 12:
                            KOSpieleLand1[14] = momentanerSieger;
                            break;
                        case 13:
                            KOSpieleLand2[14] = momentanerSieger;
                            break;
                        case 14:
                            Sieger = momentanerSieger;
                            break;


                    }
                    KOMomentanesSpiel++;
                    UpdateKo();
                    if (KOMomentanesSpiel < 15) UpdateKOEingabe();
                    else
                    {
                        lbKODatum.Visibility = Visibility.Hidden;
                        lbKOLand1.Visibility = Visibility.Hidden;
                        lbKOLand2.Visibility = Visibility.Hidden;
                        tbKOLand1.Visibility = Visibility.Hidden;
                        tbKOLand2.Visibility = Visibility.Hidden;
                        btKOSpeichern.Visibility = Visibility.Hidden;
                    }


                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Bitte geben sie gültige Werte für die Tore ein!");
                if (KOMomentanesSpiel < 15) UpdateKOEingabe();
            }
        }

        private void UpdateKOEingabe()
        {
            lbKODatum.Content = KOSpieleDatum[KOMomentanesSpiel];
            lbKOLand1.Content = KOSpieleLand1[KOMomentanesSpiel];
            lbKOLand2.Content = KOSpieleLand2[KOMomentanesSpiel];
            //auto 1
            //tbKOLand1.Text = "";
            //tbKOLand2.Text = "";
        }
        private void InitialisiereKODaten()
        {
            gdGruppenphase.Visibility = Visibility.Hidden;
            gdKophase.Visibility = Visibility.Visible;
            KOMomentanesSpiel = 0;
            KOSpieleDatum = new string[] { "29.06.2024", "29.06.2024", "30.06.2024", "30.06.2024", "01.07.2024", "01.07.2024", "02.07.2024", "02.07.2024", "05.07.2024", "05.07.2024", "06.07.2024", "06.07.2024", "09.07.2024", "10.07.2024", "14.07.2024" };
            KOSpieleLand1 = new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" };
            KOSpieleLand2 = new string[] { "", "", "", "", "", "", "", "", "", "", "", "", "", "", "" };
            int[] reihenfolgeA = new int[] { -1, -1, -1 };
            Sieger = "";
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeA.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeAPunkte[j] > GruppeAPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeAPunkte[j] == GruppeAPunkte[besterIndex])
                            {
                                if (GruppeAToreGeschossen[j] - GruppeAToreErhalten[j] > GruppeAToreGeschossen[besterIndex] - GruppeAToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeAToreGeschossen[j] - GruppeAToreErhalten[j] == GruppeAToreGeschossen[besterIndex] - GruppeAToreErhalten[besterIndex])
                                {
                                    if (GruppeAToreGeschossen[j] > GruppeAToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeAToreGeschossen[j] == GruppeAToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeA[i] = besterIndex;
            }

            int[] reihenfolgeB = new int[] { -1, -1, -1 };
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeB.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeBPunkte[j] > GruppeBPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeBPunkte[j] == GruppeBPunkte[besterIndex])
                            {
                                if (GruppeBToreGeschossen[j] - GruppeBToreErhalten[j] > GruppeBToreGeschossen[besterIndex] - GruppeBToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeBToreGeschossen[j] - GruppeBToreErhalten[j] == GruppeBToreGeschossen[besterIndex] - GruppeBToreErhalten[besterIndex])
                                {
                                    if (GruppeBToreGeschossen[j] > GruppeBToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeBToreGeschossen[j] == GruppeBToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeB[i] = besterIndex;
            }

            int[] reihenfolgeC = new int[] { -1, -1, -1 };
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeC.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeCPunkte[j] > GruppeCPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeCPunkte[j] == GruppeCPunkte[besterIndex])
                            {
                                if (GruppeCToreGeschossen[j] - GruppeCToreErhalten[j] > GruppeCToreGeschossen[besterIndex] - GruppeCToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeCToreGeschossen[j] - GruppeCToreErhalten[j] == GruppeCToreGeschossen[besterIndex] - GruppeCToreErhalten[besterIndex])
                                {
                                    if (GruppeCToreGeschossen[j] > GruppeCToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeCToreGeschossen[j] == GruppeCToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeC[i] = besterIndex;
            }

            int[] reihenfolgeD = new int[] { -1, -1, -1 };
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeD.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeDPunkte[j] > GruppeDPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeDPunkte[j] == GruppeDPunkte[besterIndex])
                            {
                                if (GruppeDToreGeschossen[j] - GruppeDToreErhalten[j] > GruppeDToreGeschossen[besterIndex] - GruppeDToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeDToreGeschossen[j] - GruppeDToreErhalten[j] == GruppeDToreGeschossen[besterIndex] - GruppeDToreErhalten[besterIndex])
                                {
                                    if (GruppeDToreGeschossen[j] > GruppeDToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeDToreGeschossen[j] == GruppeDToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeD[i] = besterIndex;
            }

            int[] reihenfolgeE = new int[] { -1, -1, -1 };
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeE.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeEPunkte[j] > GruppeEPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeEPunkte[j] == GruppeEPunkte[besterIndex])
                            {
                                if (GruppeEToreGeschossen[j] - GruppeEToreErhalten[j] > GruppeEToreGeschossen[besterIndex] - GruppeEToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeEToreGeschossen[j] - GruppeEToreErhalten[j] == GruppeEToreGeschossen[besterIndex] - GruppeEToreErhalten[besterIndex])
                                {
                                    if (GruppeEToreGeschossen[j] > GruppeEToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeEToreGeschossen[j] == GruppeEToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeE[i] = besterIndex;
            }

            int[] reihenfolgeF = new int[] { -1, -1, -1 };
            for (int i = 0; i < 3; i++)
            {
                int besterIndex = -1;
                for (int j = 0; j < 4; j++)
                {
                    if (!reihenfolgeF.Contains(j))
                    {
                        if (besterIndex == -1)
                        {
                            besterIndex = j;
                        }
                        else
                        {
                            if (GruppeFPunkte[j] > GruppeFPunkte[besterIndex])
                            {
                                besterIndex = j;
                            }
                            else if (GruppeFPunkte[j] == GruppeFPunkte[besterIndex])
                            {
                                if (GruppeFToreGeschossen[j] - GruppeFToreErhalten[j] > GruppeFToreGeschossen[besterIndex] - GruppeFToreErhalten[besterIndex])
                                {
                                    besterIndex = j;
                                }
                                else if (GruppeFToreGeschossen[j] - GruppeFToreErhalten[j] == GruppeFToreGeschossen[besterIndex] - GruppeFToreErhalten[besterIndex])
                                {
                                    if (GruppeFToreGeschossen[j] > GruppeFToreGeschossen[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeFToreGeschossen[j] == GruppeFToreGeschossen[besterIndex])
                                    {
                                        if (new Random().Next(0, 2) == 1)
                                        {
                                            besterIndex = j;
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                reihenfolgeF[i] = besterIndex;
            }
            string[] ZwischenGruppeANamen = new string[3];
            int[] ZwischenGruppeAPunkte = new int[3];
            int[] ZwischenGruppeAToreGeschossen = new int[3];
            int[] ZwischenGruppeAToreErhalten = new int[3];
            string[] ZwischenGruppeBNamen = new string[3];
            int[] ZwischenGruppeBPunkte = new int[3];
            int[] ZwischenGruppeBToreGeschossen = new int[3];
            int[] ZwischenGruppeBToreErhalten = new int[3];
            string[] ZwischenGruppeCNamen = new string[3];
            int[] ZwischenGruppeCPunkte = new int[3];
            int[] ZwischenGruppeCToreGeschossen = new int[3];
            int[] ZwischenGruppeCToreErhalten = new int[3];
            string[] ZwischenGruppeDNamen = new string[3];
            int[] ZwischenGruppeDPunkte = new int[3];
            int[] ZwischenGruppeDToreGeschossen = new int[3];
            int[] ZwischenGruppeDToreErhalten = new int[3];
            string[] ZwischenGruppeENamen = new string[3];
            int[] ZwischenGruppeEPunkte = new int[3];
            int[] ZwischenGruppeEToreGeschossen = new int[3];
            int[] ZwischenGruppeEToreErhalten = new int[3];
            string[] ZwischenGruppeFNamen = new string[3];
            int[] ZwischenGruppeFPunkte = new int[3];
            int[] ZwischenGruppeFToreGeschossen = new int[3];
            int[] ZwischenGruppeFToreErhalten = new int[3];

            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeANamen[i] = GruppeANamen[reihenfolgeA[i]];
                ZwischenGruppeAPunkte[i] = GruppeAPunkte[reihenfolgeA[i]];
                ZwischenGruppeAToreGeschossen[i] = GruppeAToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeAToreErhalten[i] = GruppeAToreErhalten[reihenfolgeA[i]];
            }
            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeBNamen[i] = GruppeBNamen[reihenfolgeA[i]];
                ZwischenGruppeBPunkte[i] = GruppeBPunkte[reihenfolgeA[i]];
                ZwischenGruppeBToreGeschossen[i] = GruppeBToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeBToreErhalten[i] = GruppeBToreErhalten[reihenfolgeA[i]];
            }
            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeCNamen[i] = GruppeCNamen[reihenfolgeA[i]];
                ZwischenGruppeCPunkte[i] = GruppeCPunkte[reihenfolgeA[i]];
                ZwischenGruppeCToreGeschossen[i] = GruppeCToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeCToreErhalten[i] = GruppeCToreErhalten[reihenfolgeA[i]];
            }
            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeDNamen[i] = GruppeDNamen[reihenfolgeA[i]];
                ZwischenGruppeDPunkte[i] = GruppeDPunkte[reihenfolgeA[i]];
                ZwischenGruppeDToreGeschossen[i] = GruppeDToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeDToreErhalten[i] = GruppeDToreErhalten[reihenfolgeA[i]];
            }
            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeENamen[i] = GruppeENamen[reihenfolgeA[i]];
                ZwischenGruppeEPunkte[i] = GruppeEPunkte[reihenfolgeA[i]];
                ZwischenGruppeEToreGeschossen[i] = GruppeEToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeEToreErhalten[i] = GruppeEToreErhalten[reihenfolgeA[i]];
            }
            for (int i = 0; i < 3; i++)
            {
                ZwischenGruppeFNamen[i] = GruppeFNamen[reihenfolgeA[i]];
                ZwischenGruppeFPunkte[i] = GruppeFPunkte[reihenfolgeA[i]];
                ZwischenGruppeFToreGeschossen[i] = GruppeFToreGeschossen[reihenfolgeA[i]];
                ZwischenGruppeFToreErhalten[i] = GruppeFToreErhalten[reihenfolgeA[i]];
            }


            KOSpieleLand1[0] = ZwischenGruppeANamen[1];
            KOSpieleLand2[0] = ZwischenGruppeBNamen[1];
            KOSpieleLand1[1] = ZwischenGruppeANamen[0];
            KOSpieleLand2[1] = ZwischenGruppeCNamen[1];

            KOSpieleLand1[2] = ZwischenGruppeCNamen[0];

            KOSpieleLand2[2] = ZwischenGruppeDNamen[2]; //3DEF

            KOSpieleLand1[3] = ZwischenGruppeBNamen[0];

            KOSpieleLand2[3] = ZwischenGruppeANamen[2]; //3ADEF

            KOSpieleLand1[4] = ZwischenGruppeDNamen[1];
            KOSpieleLand2[4] = ZwischenGruppeENamen[1];
            KOSpieleLand1[5] = ZwischenGruppeFNamen[0];

            KOSpieleLand2[5] = ZwischenGruppeBNamen[2]; //3ABC

            KOSpieleLand1[6] = ZwischenGruppeDNamen[0];
            KOSpieleLand2[6] = ZwischenGruppeFNamen[1];
            KOSpieleLand1[7] = ZwischenGruppeENamen[0];

            KOSpieleLand2[7] = ZwischenGruppeCNamen[2]; //3ABCD




            UpdateKOEingabe();
            UpdateKo();
        }

        private void UpdateKo()
        {
            lbAchtel1Land1.Content = KOSpieleLand1[0];
            lbAchtel1Land2.Content = KOSpieleLand2[0];
            lbAchtel2Land1.Content = KOSpieleLand1[1];
            lbAchtel2Land2.Content = KOSpieleLand2[1];
            lbAchtel3Land1.Content = KOSpieleLand1[2];
            lbAchtel3Land2.Content = KOSpieleLand2[2];
            lbAchtel4Land1.Content = KOSpieleLand1[3];
            lbAchtel4Land2.Content = KOSpieleLand2[3];
            lbAchtel5Land1.Content = KOSpieleLand1[4];
            lbAchtel5Land2.Content = KOSpieleLand2[4];
            lbAchtel6Land1.Content = KOSpieleLand1[5];
            lbAchtel6Land2.Content = KOSpieleLand2[5];
            lbAchtel7Land1.Content = KOSpieleLand1[6];
            lbAchtel7Land2.Content = KOSpieleLand2[6];
            lbAchtel8Land1.Content = KOSpieleLand1[7];
            lbAchtel8Land2.Content = KOSpieleLand2[7];

            lbViertel1Land1.Content = KOSpieleLand1[8];
            lbViertel1Land2.Content = KOSpieleLand2[8];
            lbViertel2Land1.Content = KOSpieleLand1[9];
            lbViertel2Land2.Content = KOSpieleLand2[9];
            lbViertel3Land1.Content = KOSpieleLand1[10];
            lbViertel3Land2.Content = KOSpieleLand2[10];
            lbViertel4Land1.Content = KOSpieleLand1[11];
            lbViertel4Land2.Content = KOSpieleLand2[11];

            lbHalb1Land1.Content = KOSpieleLand1[12];
            lbHalb1Land2.Content = KOSpieleLand2[12];
            lbHalb2Land1.Content = KOSpieleLand1[13];
            lbHalb2Land2.Content = KOSpieleLand2[13];
            lbFinaleLand1.Content = KOSpieleLand1[14];
            lbFinaleLand2.Content = KOSpieleLand2[14];
            lbSieger.Content = Sieger;
        }
        private void cbGruppenAuswahl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (cbGruppenAuswahl.SelectedItem != null)
            {
                switch (cbGruppenAuswahl.SelectedItem)
                {
                    case "GruppeA":
                        UpdateTabelle("A");
                        break;
                    case "GruppeB":
                        UpdateTabelle("B");
                        break;
                    case "GruppeC":
                        UpdateTabelle("C");
                        break;
                    case "GruppeD":
                        UpdateTabelle("D");
                        break;
                    case "GruppeE":
                        UpdateTabelle("E");
                        break;
                    case "GruppeF":
                        UpdateTabelle("F");
                        break;
                }
            }
        }


        public MainWindow()
        {

            InitializeComponent();
            InitialisiereDaten();
            UpdateEingabe();
        }
        private void InitialisiereDaten()
        {
            cbGruppenAuswahl.Items.Add("GruppeA");
            cbGruppenAuswahl.Items.Add("GruppeB");
            cbGruppenAuswahl.Items.Add("GruppeC");
            cbGruppenAuswahl.Items.Add("GruppeD");
            cbGruppenAuswahl.Items.Add("GruppeE");
            cbGruppenAuswahl.Items.Add("GruppeF");
            MomentanesSpiel = 0;
            GruppeANamen = new string[] { "Deutschland", "Schottland", "Schweiz", "Ungarn", };
            GruppeBNamen = new string[] { "Spanien", "Kroatien", "Italien", "Albanien", };
            GruppeCNamen = new string[] { "England", "Slowenien", "Dänemark", "Serbien", };
            GruppeDNamen = new string[] { "Niederlande", "Österreich", "Frankreich", "Polen", };
            GruppeENamen = new string[] { "Belgien", "Slowakei", "Rumänien", "Ukraine", };
            GruppeFNamen = new string[] { "Türkei", "Portugal", "Tschechien", "Georgien", };
            GruppeAPunkte = new int[] { 0, 0, 0, 0 };
            GruppeBPunkte = new int[] { 0, 0, 0, 0 };
            GruppeCPunkte = new int[] { 0, 0, 0, 0 };
            GruppeDPunkte = new int[] { 0, 0, 0, 0 };
            GruppeEPunkte = new int[] { 0, 0, 0, 0 };
            GruppeFPunkte = new int[] { 0, 0, 0, 0 };
            GruppeAToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeBToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeCToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeDToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeEToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeFToreGeschossen = new int[] { 0, 0, 0, 0 };
            GruppeAToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeBToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeCToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeDToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeEToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeFToreErhalten = new int[] { 0, 0, 0, 0 };
            GruppeASiege = new int[] { 0, 0, 0, 0 };
            GruppeBSiege = new int[] { 0, 0, 0, 0 };
            GruppeCSiege = new int[] { 0, 0, 0, 0 };
            GruppeDSiege = new int[] { 0, 0, 0, 0 };
            GruppeESiege = new int[] { 0, 0, 0, 0 };
            GruppeFSiege = new int[] { 0, 0, 0, 0 };
            GruppeANiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeBNiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeCNiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeDNiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeENiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeFNiederlagen = new int[] { 0, 0, 0, 0 };
            GruppeAUnentschieden = new int[] { 0, 0, 0, 0 };
            GruppeBUnentschieden = new int[] { 0, 0, 0, 0 };
            GruppeCUnentschieden = new int[] { 0, 0, 0, 0 };
            GruppeDUnentschieden = new int[] { 0, 0, 0, 0 };
            GruppeEUnentschieden = new int[] { 0, 0, 0, 0 };
            GruppeFUnentschieden = new int[] { 0, 0, 0, 0 };
            SpieleGruppen = new string[] { "A", "A", "B", "B", "C", "C", "D", "D", "E", "E", "F", "F", "A", "A", "B", "B", "C", "C", "D", "D", "E", "E", "F", "F", "A", "A", "B", "B", "C", "C", "D", "D", "E", "E", "F", "F", };
            SpieleDatum = new string[] { "14.06.2024", "15.06.2024", "15.06.2024", "15.06.2024", "16.06.2024", "16.06.2024", "16.06.2024", "17.06.2024", "17.06.2024", "17.06.2024", "18.06.2024", "18.06.2024", "19.06.2024", "19.06.2024", "19.06.2024", "20.06.2024", "20.06.2024", "20.06.2024", "21.06.2024", "21.06.2024", "21.06.2024", "22.06.2024", "22.06.2024", "22.06.2024", "23.06.2024", "23.06.2024", "24.06.2024", "24.06.2024", "25.06.2024", "25.06.2024", "25.06.2024", "25.06.2024", "26.06.2024", "26.06.2024", "26.06.2024", "26.06.2024", };
            SpieleLand1 = new int[] { 0, 3, 0, 2, 1, 3, 3, 1, 2, 0, 0, 1, 0, 1, 1, 0, 1, 2, 3, 0, 1, 0, 3, 0, 2, 1, 3, 1, 0, 2, 2, 0, 3, 1, 2, 3, };
            SpieleLand2 = new int[] { 1, 2, 1, 3, 2, 0, 0, 2, 3, 1, 3, 2, 3, 2, 3, 2, 3, 0, 1, 2, 3, 2, 2, 1, 0, 3, 0, 2, 1, 3, 3, 1, 0, 2, 0, 1, };
        }

        private void btSpeichern_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int Tore1 = Convert.ToInt32(tbLand1.Text);
                int Tore2 = Convert.ToInt32(tbLand2.Text);
                switch (SpieleGruppen[MomentanesSpiel])
                {
                    case "A":
                        GruppeAToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeAToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeAToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeAToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeAPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeASiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeANiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeAPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeASiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeANiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeAPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeAPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeAUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeAUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                    case "B":
                        GruppeBToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeBToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeBToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeBToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeBPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeBSiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeBNiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeBPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeBSiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeBNiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeBPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeBPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeBUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeBUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                    case "C":
                        GruppeCToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeCToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeCToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeCToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeCPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeCSiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeCNiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeCPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeCSiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeCNiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeCPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeCPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeCUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeCUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                    case "D":
                        GruppeDToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeDToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeDToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeDToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeDPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeDSiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeDNiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeDPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeDSiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeDNiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeDPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeDPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeDUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeDUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                    case "E":
                        GruppeEToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeEToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeEToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeEToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeEPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeESiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeENiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeEPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeESiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeENiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeEPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeEPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeEUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeEUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                    case "F":
                        GruppeFToreGeschossen[SpieleLand1[MomentanesSpiel]] += Tore1;
                        GruppeFToreErhalten[SpieleLand1[MomentanesSpiel]] += Tore2;
                        GruppeFToreGeschossen[SpieleLand2[MomentanesSpiel]] += Tore2;
                        GruppeFToreErhalten[SpieleLand2[MomentanesSpiel]] += Tore1;
                        if (Tore1 > Tore2)
                        {
                            GruppeFPunkte[SpieleLand1[MomentanesSpiel]] += 3;
                            GruppeFSiege[SpieleLand1[MomentanesSpiel]]++;
                            GruppeFNiederlagen[SpieleLand2[MomentanesSpiel]]++;
                        }
                        else if (Tore2 > Tore1)
                        {
                            GruppeFPunkte[SpieleLand2[MomentanesSpiel]] += 3;
                            GruppeFSiege[SpieleLand2[MomentanesSpiel]]++;
                            GruppeFNiederlagen[SpieleLand1[MomentanesSpiel]]++;
                        }
                        else
                        {
                            GruppeFPunkte[SpieleLand1[MomentanesSpiel]]++;
                            GruppeFPunkte[SpieleLand2[MomentanesSpiel]]++;
                            GruppeFUnentschieden[SpieleLand1[MomentanesSpiel]]++;
                            GruppeFUnentschieden[SpieleLand2[MomentanesSpiel]]++;
                        }
                        break;
                }
                MomentanesSpiel++;
                if (MomentanesSpiel == 36)
                {
                    InitialisiereKODaten();
                }
                else
                {
                    UpdateEingabe();
                    if (cbGruppenAuswahl.SelectedItem != null)
                    {
                        switch (cbGruppenAuswahl.SelectedItem)
                        {
                            case "GruppeA":
                                UpdateTabelle("A");
                                break;
                            case "GruppeB":
                                UpdateTabelle("B");
                                break;
                            case "GruppeC":
                                UpdateTabelle("C");
                                break;
                            case "GruppeD":
                                UpdateTabelle("D");
                                break;
                            case "GruppeE":
                                UpdateTabelle("E");
                                break;
                            case "GruppeF":
                                UpdateTabelle("F");
                                break;
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                MessageBox.Show("Bitte geben sie gültige Werte für die Tore ein!");
                UpdateEingabe();
            }
        }

        private void UpdateTabelle(string GruppenBuchstabe)
        {
            int[] reihenfolge = new int[] { -1, -1, -1, -1 };
            switch (GruppenBuchstabe)
            {
                case "A":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeAPunkte[j] > GruppeAPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeAPunkte[j] == GruppeAPunkte[besterIndex])
                                    {
                                        if (GruppeAToreGeschossen[j] - GruppeAToreErhalten[j] > GruppeAToreGeschossen[besterIndex] - GruppeAToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeAToreGeschossen[j] - GruppeAToreErhalten[j] == GruppeAToreGeschossen[besterIndex] - GruppeAToreErhalten[besterIndex])
                                        {
                                            if (GruppeAToreGeschossen[j] > GruppeAToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeAToreGeschossen[j] == GruppeAToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeANamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeAPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeASiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeANiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeAToreGeschossen[reihenfolge[i]] - GruppeAToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeANamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeAPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeASiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeANiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeAToreGeschossen[reihenfolge[i]] - GruppeAToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeANamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeAPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeASiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeANiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeAToreGeschossen[reihenfolge[i]] - GruppeAToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeANamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeAPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeASiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeANiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeAToreGeschossen[reihenfolge[i]] - GruppeAToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
                case "B":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeBPunkte[j] > GruppeBPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeBPunkte[j] == GruppeBPunkte[besterIndex])
                                    {
                                        if (GruppeBToreGeschossen[j] - GruppeBToreErhalten[j] > GruppeBToreGeschossen[besterIndex] - GruppeBToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeBToreGeschossen[j] - GruppeBToreErhalten[j] == GruppeBToreGeschossen[besterIndex] - GruppeBToreErhalten[besterIndex])
                                        {
                                            if (GruppeBToreGeschossen[j] > GruppeBToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeBToreGeschossen[j] == GruppeBToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeBNamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeBPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeBSiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeBNiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeBToreGeschossen[reihenfolge[i]] - GruppeBToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeBNamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeBPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeBSiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeBNiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeBToreGeschossen[reihenfolge[i]] - GruppeBToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeBNamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeBPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeBSiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeBNiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeBToreGeschossen[reihenfolge[i]] - GruppeBToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeBNamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeBPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeBSiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeBNiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeBToreGeschossen[reihenfolge[i]] - GruppeBToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
                case "C":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeCPunkte[j] > GruppeCPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeCPunkte[j] == GruppeCPunkte[besterIndex])
                                    {
                                        if (GruppeCToreGeschossen[j] - GruppeCToreErhalten[j] > GruppeCToreGeschossen[besterIndex] - GruppeCToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeCToreGeschossen[j] - GruppeCToreErhalten[j] == GruppeCToreGeschossen[besterIndex] - GruppeCToreErhalten[besterIndex])
                                        {
                                            if (GruppeCToreGeschossen[j] > GruppeCToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeCToreGeschossen[j] == GruppeCToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeCNamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeCPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeCSiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeCNiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeCToreGeschossen[reihenfolge[i]] - GruppeCToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeCNamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeCPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeCSiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeCNiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeCToreGeschossen[reihenfolge[i]] - GruppeCToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeCNamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeCPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeCSiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeCNiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeCToreGeschossen[reihenfolge[i]] - GruppeCToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeCNamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeCPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeCSiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeCNiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeCToreGeschossen[reihenfolge[i]] - GruppeCToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
                case "D":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeDPunkte[j] > GruppeDPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeDPunkte[j] == GruppeDPunkte[besterIndex])
                                    {
                                        if (GruppeDToreGeschossen[j] - GruppeDToreErhalten[j] > GruppeDToreGeschossen[besterIndex] - GruppeDToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeDToreGeschossen[j] - GruppeDToreErhalten[j] == GruppeDToreGeschossen[besterIndex] - GruppeDToreErhalten[besterIndex])
                                        {
                                            if (GruppeDToreGeschossen[j] > GruppeDToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeDToreGeschossen[j] == GruppeDToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeDNamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeDPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeDSiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeDNiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeDToreGeschossen[reihenfolge[i]] - GruppeDToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeDNamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeDPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeDSiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeDNiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeDToreGeschossen[reihenfolge[i]] - GruppeDToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeDNamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeDPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeDSiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeDNiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeDToreGeschossen[reihenfolge[i]] - GruppeDToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeDNamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeDPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeDSiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeDNiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeDToreGeschossen[reihenfolge[i]] - GruppeDToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
                case "E":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeEPunkte[j] > GruppeEPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeEPunkte[j] == GruppeEPunkte[besterIndex])
                                    {
                                        if (GruppeEToreGeschossen[j] - GruppeEToreErhalten[j] > GruppeEToreGeschossen[besterIndex] - GruppeEToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeEToreGeschossen[j] - GruppeEToreErhalten[j] == GruppeEToreGeschossen[besterIndex] - GruppeEToreErhalten[besterIndex])
                                        {
                                            if (GruppeEToreGeschossen[j] > GruppeEToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeEToreGeschossen[j] == GruppeEToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeENamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeEPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeESiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeENiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeEToreGeschossen[reihenfolge[i]] - GruppeEToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeENamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeEPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeESiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeENiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeEToreGeschossen[reihenfolge[i]] - GruppeEToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeENamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeEPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeESiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeENiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeEToreGeschossen[reihenfolge[i]] - GruppeEToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeENamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeEPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeESiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeENiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeEToreGeschossen[reihenfolge[i]] - GruppeEToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
                case "F":
                    for (int i = 0; i < 4; i++)
                    {
                        int besterIndex = -1;
                        for (int j = 0; j < 4; j++)
                        {
                            if (!reihenfolge.Contains(j))
                            {
                                if (besterIndex == -1)
                                {
                                    besterIndex = j;
                                }
                                else
                                {
                                    if (GruppeFPunkte[j] > GruppeFPunkte[besterIndex])
                                    {
                                        besterIndex = j;
                                    }
                                    else if (GruppeFPunkte[j] == GruppeFPunkte[besterIndex])
                                    {
                                        if (GruppeFToreGeschossen[j] - GruppeFToreErhalten[j] > GruppeFToreGeschossen[besterIndex] - GruppeFToreErhalten[besterIndex])
                                        {
                                            besterIndex = j;
                                        }
                                        else if (GruppeFToreGeschossen[j] - GruppeFToreErhalten[j] == GruppeFToreGeschossen[besterIndex] - GruppeFToreErhalten[besterIndex])
                                        {
                                            if (GruppeFToreGeschossen[j] > GruppeFToreGeschossen[besterIndex])
                                            {
                                                besterIndex = j;
                                            }
                                            else if (GruppeFToreGeschossen[j] == GruppeFToreGeschossen[besterIndex])
                                            {
                                                if (new Random().Next(0, 2) == 1)
                                                {
                                                    besterIndex = j;
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        reihenfolge[i] = besterIndex;
                    }
                    for (int i = 0; i < 4; i++)
                    {
                        switch (i)
                        {

                            case 0:
                                tableLand1.Content = GruppeFNamen[reihenfolge[i]];
                                tablePunkte1.Content = GruppeFPunkte[reihenfolge[i]];
                                tableSiege1.Content = GruppeFSiege[reihenfolge[i]];
                                tableNiederlagen1.Content = GruppeFNiederlagen[reihenfolge[i]];
                                tableTordifferenz1.Content = GruppeFToreGeschossen[reihenfolge[i]] - GruppeFToreErhalten[reihenfolge[i]];
                                break;

                            case 1:
                                tableLand2.Content = GruppeFNamen[reihenfolge[i]];
                                tablePunkte2.Content = GruppeFPunkte[reihenfolge[i]];
                                tableSiege2.Content = GruppeFSiege[reihenfolge[i]];
                                tableNiederlagen2.Content = GruppeFNiederlagen[reihenfolge[i]];
                                tableTordifferenz2.Content = GruppeFToreGeschossen[reihenfolge[i]] - GruppeFToreErhalten[reihenfolge[i]];
                                break;

                            case 2:
                                tableLand3.Content = GruppeFNamen[reihenfolge[i]];
                                tablePunkte3.Content = GruppeFPunkte[reihenfolge[i]];
                                tableSiege3.Content = GruppeFSiege[reihenfolge[i]];
                                tableNiederlagen3.Content = GruppeFNiederlagen[reihenfolge[i]];
                                tableTordifferenz3.Content = GruppeFToreGeschossen[reihenfolge[i]] - GruppeFToreErhalten[reihenfolge[i]];
                                break;

                            case 3:
                                tableLand4.Content = GruppeFNamen[reihenfolge[i]];
                                tablePunkte4.Content = GruppeFPunkte[reihenfolge[i]];
                                tableSiege4.Content = GruppeFSiege[reihenfolge[i]];
                                tableNiederlagen4.Content = GruppeFNiederlagen[reihenfolge[i]];
                                tableTordifferenz4.Content = GruppeFToreGeschossen[reihenfolge[i]] - GruppeFToreErhalten[reihenfolge[i]];
                                break;

                        }
                    }
                    break;
            }
        }
        private void UpdateEingabe()
        {
            //auto 2
            //tbLand1.Text = "";
            //tbLand2.Text = "";
            lbDatum.Content = SpieleDatum[MomentanesSpiel];
            lbGruppe.Content = SpieleGruppen[MomentanesSpiel];
            switch (SpieleGruppen[MomentanesSpiel])
            {
                case "A":
                    lbLand1.Content = GruppeANamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeANamen[SpieleLand2[MomentanesSpiel]];
                    break;
                case "B":
                    lbLand1.Content = GruppeBNamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeBNamen[SpieleLand2[MomentanesSpiel]];
                    break;
                case "C":
                    lbLand1.Content = GruppeCNamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeCNamen[SpieleLand2[MomentanesSpiel]];
                    break;
                case "D":
                    lbLand1.Content = GruppeDNamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeDNamen[SpieleLand2[MomentanesSpiel]];
                    break;
                case "E":
                    lbLand1.Content = GruppeENamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeENamen[SpieleLand2[MomentanesSpiel]];
                    break;
                case "F":
                    lbLand1.Content = GruppeFNamen[SpieleLand1[MomentanesSpiel]];
                    lbLand2.Content = GruppeFNamen[SpieleLand2[MomentanesSpiel]];
                    break;
            }
        }
    }
}